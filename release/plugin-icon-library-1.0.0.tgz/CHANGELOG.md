# 更新日志

本文件记录 `@xiezuo/plugin-icon-library` 的版本变更，格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [1.0.0] - 2026-09-10

首个发行版本。

### 新增

- 内置 1426 个扩展图标，全部来自开源图标库，并已内联进构建产物（运行时不发起任何外部请求）：
  - **lucide**（ISC）1371 个线性图标，已剔除与 Ant Design 内置图标同名或语义重复的部分（`User`、`Users`、`Trash`、`Pencil`、`Settings` 等不再重复提供）；
  - **Material Design Icons / MDI**（Apache-2.0）55 个数字序号图标：`0`~`10`，每个数字提供实心 / 圆形 / 圆形描边 / 方形 / 方形描边 5 种样式。
- 27 个语义分类：数字与序号、通用操作、箭头与方向、编辑与布局、用户与人物、商务与办公、文件与文档、通信与消息、多媒体与娱乐、图表与数据、开发与技术、设备与硬件、建筑与家居、交通与运输、时间与日历、天气与自然、生活与饮食、医疗与健康、教育与科研、购物与电商、安全与隐私、社交与品牌、状态与符号，以及系统图标的线框 / 实底 / 双色分类。
- 图标选择器接管以下位置，菜单、页签、按钮等界面配置均可选用扩展图标：
  - 旧版 schema 渲染的 `IconPicker` 与 `MobileMenuSettingsIconPicker`；
  - FlowEngine 设置表单中的图标字段。
- 扩展图标同时注册进 `@nocobase/client` 与 `@nocobase/client-v2` 两套图标注册表，FlowEngine 渲染的表格行按钮等位置可正常渲染。
- 支持英文名称与中文关键词搜索（`序号`、`终端`、`服务器`、`useradd → 用户` 均可命中），命中范围覆盖扩展图标与系统图标。
- 图标弹层按每页 240 个滚动加载，避免一次性渲染 1400+ 图标造成的卡顿。
- 图标名称统一为 `Xz` 前缀 + `Outlined` 后缀（例如 `XzTerminalOutlined`），保存值仍为普通字符串。

### 说明

- 图标名中的 `Xz` 前缀是稳定契约，用于避免覆盖系统图标；升级版本不会改动已发布图标的名称。
- 兼容 NocoBase 2.x（构建基线 2.2.9）与 React 18。

[1.0.0]: https://github.com/charce526/plugin-icon-library/releases/tag/v1.0.0
